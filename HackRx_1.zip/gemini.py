# test_gemini.py

import os
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
from google.api_core.exceptions import GoogleAPICallError

def test_gemini_api_key():
    """
    A simple script to test if the Google Gemini API key is working.
    """
    print("--- Starting Gemini API Key Test ---")
    
    # 1. Load environment variables from .env file
    load_dotenv()
    api_key = os.getenv("GOOGLE_API_KEY")

    if not api_key:
        print("\n❌ ERROR: GOOGLE_API_KEY not found in .env file.")
        print("Please ensure your .env file is in the same directory and contains the key.")
        return

    print("✅ API Key loaded from .env file.")

    # 2. Try to initialize and use the Gemini LLM
    try:
        print("Initializing Gemini model...")
        llm = ChatGoogleGenerativeAI(model="gemini-1.5-pro-latest", google_api_key=api_key)
        
        print("Model initialized. Sending a test prompt...")
        prompt = "What is the capital of India? Respond with only the name of the city."
        
        response = llm.invoke(prompt)
        
        print("\n🎉 SUCCESS! API call was successful.")
        print("-" * 20)
        print(f"Prompt: {prompt}")
        print(f"Gemini Response: {response.content}")
        print("-" * 20)

    except GoogleAPICallError as e:
        print("\n❌ FAILURE: The API call failed. This confirms an issue with your key or Google Cloud project.")
        print("-" * 20)
        print(f"Error Type: {type(e).__name__}")
        print(f"Error Message: {e}")
        print("-" * 20)
        print("Common Causes:")
        print("  - The API key is incorrect, expired, or has been revoked.")
        print("  - The 'Generative Language API' is not enabled in your Google Cloud project.")
        print("  - Your Google Cloud project does not have a billing account enabled (required for some models/features).")
        print("  - You have exhausted your free tier quota.")
        
    except Exception as e:
        print(f"\n❌ An unexpected error occurred: {e}")

if __name__ == "__main__":
    test_gemini_api_key()
